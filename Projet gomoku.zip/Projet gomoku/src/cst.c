#include "cst.h"
#include <SDL.h>

SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;

SDL_Texture *textureMenu = NULL;
SDL_Texture *textureRegles = NULL;
SDL_Texture *textureMenuChoixJoueur = NULL;
SDL_Texture *textureMenuChoixMode = NULL;
SDL_Texture *textureMenuChoixIA = NULL;

SDL_Texture *texturePionNoir = NULL;
SDL_Texture *textureExAeqo = NULL;
SDL_Texture *texturePionBlanc = NULL;
SDL_Texture *textureJeu = NULL;

SDL_Texture *textureMenuFin = NULL;
SDL_Texture *textureRetourMenuFin = NULL;

const double rac2 = 1.41213562;
